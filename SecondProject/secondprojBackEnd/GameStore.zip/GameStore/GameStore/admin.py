from .models import Modalidade, Liga, Grupo, Equipa, Jogador, Jogo, Evento, Classificacao, User, FantasyTeam
from django.contrib import admin
# Register your models here
admin.site.register(Modalidade)
admin.site.register(Liga)
admin.site.register(Grupo)
admin.site.register(Equipa)
admin.site.register(Jogador)
admin.site.register(Jogo)
admin.site.register(Evento)
admin.site.register(Classificacao)
admin.site.register(User)
admin.site.register(FantasyTeam)